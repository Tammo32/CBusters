
#include "Node.h"

Node::Node(Tile* tile, Node* next)
{
   // TODO 
}

Node::Node(Node& other)
{
   // TODO
}
